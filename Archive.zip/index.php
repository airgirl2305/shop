<?php

require_once("router.php"); // connect to the file
